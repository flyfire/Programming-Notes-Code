package com.sxdsf.async.imitate1;

/**
 * com.sxdsf.async.Calling
 *
 * @author SXDSF
 * @date 2017/7/3 上午12:48
 * @desc 描述打电话
 */

public interface Calling {

    void unCall();

    boolean isUnCalled();
}
