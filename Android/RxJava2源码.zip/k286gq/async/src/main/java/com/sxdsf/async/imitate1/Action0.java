package com.sxdsf.async.imitate1;

/**
 * com.sxdsf.async.imitate1.Action0
 *
 * @author SXDSF
 * @date 2017/11/14 下午10:33
 * @desc
 */

public interface Action0 {

    void call();
}
