package com.sxdsf.async.imitate2;

/**
 * com.sxdsf.async.imitate2.CallerEmitter
 *
 * @author SXDSF
 * @date 2017/11/7 上午7:55
 * @desc 打电话的人的电话
 */

public interface CallerEmitter<T> extends Emitter<T> {
}
