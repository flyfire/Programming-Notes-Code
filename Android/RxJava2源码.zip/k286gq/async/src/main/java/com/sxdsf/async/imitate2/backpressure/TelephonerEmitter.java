package com.sxdsf.async.imitate2.backpressure;

import com.sxdsf.async.imitate2.Emitter;

/**
 * com.sxdsf.async.imitate2.backpressure.TelephonerEmitter
 *
 * @author SXDSF
 * @date 2017/11/7 下午1:31
 * @desc 打电话的人的电话
 */

public interface TelephonerEmitter<T> extends Emitter<T> {
}
