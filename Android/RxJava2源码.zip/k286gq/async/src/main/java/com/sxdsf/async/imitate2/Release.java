package com.sxdsf.async.imitate2;

/**
 * com.sxdsf.async.imitate2.Release
 *
 * @author SXDSF
 * @date 2017/11/5 下午11:39
 * @desc 挂断电话
 */

public interface Release {

    boolean isReleased();

    void release();
}
