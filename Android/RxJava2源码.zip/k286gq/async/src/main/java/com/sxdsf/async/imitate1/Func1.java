package com.sxdsf.async.imitate1;

/**
 * com.sxdsf.async.Func1
 *
 * @author SXDSF
 * @date 2017/9/11 上午10:24
 * @desc function调用
 */

public interface Func1<T, R> {

    R call(T t);
}
