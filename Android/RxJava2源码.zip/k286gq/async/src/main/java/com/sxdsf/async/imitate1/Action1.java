package com.sxdsf.async.imitate1;

/**
 * com.sxdsf.async.imitate1.Action1
 *
 * @author SXDSF
 * @date 2017/7/3 上午1:29
 * @desc 简单调用
 */

public interface Action1<T> {

    void call(T t);
}
